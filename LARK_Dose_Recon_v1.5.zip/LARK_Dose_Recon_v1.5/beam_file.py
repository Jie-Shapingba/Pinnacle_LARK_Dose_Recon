#!/usr/bin/python

# This script is for dose reconstruction of LARK patient plan on Pinnacle/Elekta
# v1.0 on 21/04/2021
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# v1.1 on 04/05/2021
# If Final Gantry Spacing is 4dgr, convert to 2dgr.
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.2 on 19/05/2021
# Fixed the track file first line variation. Ignore the heading.
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.3 on 20/05/2021
# Using control point weighting rather than MU
# GUI for user to specify files path
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.4 on 21/07/2022
# Comparing with and without LARK
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.5 on 09/02/2023
# Stop program if one of tracking file names wrong
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

import os
import sys
import os.path

xx=sys.argv[1]

path = '/home/p3rtp/RadCalc/LARK/'+xx+'_with_LARK.txt'
check_file = os.path.isfile(path)

path = '/home/p3rtp/RadCalc/LARK/'+xx+'_without_LARK.txt'
check_file1 = os.path.isfile(path)

fo=open('/usr/local/adacnew/PinnacleSiteData/Scripts/HotScripts/Physics/LARK_Dose_Recon_v1.5/BNAdd.Script','w+')
if check_file==1 and check_file1==1:
	fo.write('Store.At.BN.Add=1;')
else:
	fo.write('Store.At.BN.Add=0;')

fo.close()


