#!/usr/bin/python

# This script is for dose reconstruction of LARK patient plan on Pinnacle/Elekta
# v1.0 on 21/04/2021
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# v1.1 on 04/05/2021
# If Final Gantry Spacing is 4dgr, convert to 2dgr.
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.2 on 19/05/2021
# Fixed the track file first line variation. Ignore the heading.
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.3 on 20/05/2021
# Using control point weighting rather than MU
# GUI for user to specify files path
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.4 on 21/07/2022
# Comparing with and without LARK
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre

# Update v1.5 on 09/02/2023
# Stop program if one of tracking file names wrong
# Jianjie Luo, Medical Physicist - Nepean Cancer care centre



import sys
import os

x=sys.argv[1]

fo=open('/usr/local/adacnew/PinnacleSiteData/Scripts/HotScripts/Physics/LARK_Dose_Recon_v1.5/create_2dgr.Script','w+')

for i in range(0,int(x)):
	fo.write('Store.FloatAt.startG=TrialList.Current.BeamList.#"#'+str(i)+'".CPManager.ControlPointList.#"#0".Gantry;\n')
	fo.write('Store.FloatAt.stopG=TrialList.Current.BeamList.#"#'+str(i)+'".CPManager.ControlPointList.#"#1".Gantry;\n')
	fo.write('Store.At.startG.Subtract=Store.FloatAt.stopG;\n')
	fo.write('Store.At.startG.Absolute="";\n')
	fo.write('Store.FloatAt.Four=4;\n')
	fo.write('IF.Store.FloatAt.startG.EQUALTO.Store.FloatAt.Four.THEN.PluginManager.InversePlanningManager.InterpolateControlPointsForBeam = TrialList.Current.BeamList.#"#'+str(i)+'";\n')
	fo.write('Store.FreeAt.startG="";\n')
	fo.write('Store.FreeAt.stopG="";\n\n')
fo.write('TrialList.Current.ComputeUncomputedBeams=1;')
fo.close()
